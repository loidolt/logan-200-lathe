                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:200294
Logan 10" Lathe change gear set by Gadget047 is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

As far as I know this is a complete change gear set for the Logan 10" lathe. The specifications were given to me as follows, I don't have a Logan lathe so I have no way to verify them. If you find a problem please let me know.  
Pressure Angle  14.5  
Face width .5  
Screw gear bore .625 leyed  
Stud and idler bore .4375 no key   
Key way width .162  
Key way depth .070  
Thanks to DasWookie for providing the needed information.  
I was informed that the compound gears were wrong. the correct compound gear sizes should be 18/54 and 24/48. I've uploaded these files to the set as well. 

# Instructions

Print a least three perimiters to allow for fitting if needed. Suggested material is Taulman 618 nylon printed at 240C. Nylon needs no lubrication and has just enough give to compensate if the print is slightly oversized due to print errors. It's also easier to trim down if needed. www.taulman3d.com is the source for the 618 nylon.